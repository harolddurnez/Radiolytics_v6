import pyaudio
import numpy as np
import threading
import time
import requests
from io import BytesIO
import logging
from pydub import AudioSegment
import ffmpeg
import tempfile
import os
from collections import deque
import json

class RadioStreamCapture:
    def __init__(self, stream_url, station_name, headers=None, buffer_seconds=60):
        self.stream_url = stream_url
        self.station_name = station_name
        self.headers = headers or {}
        self.buffer_seconds = buffer_seconds
        self.is_running = False
        self.thread = None
        self.fingerprints = deque()  # (timestamp, fingerprint)
        self.audio = pyaudio.PyAudio()
        
        # Audio parameters (matching Android app)
        self.SAMPLE_RATE = 8000
        self.FRAME_SIZE = 512
        self.FRAME_OVERLAP = 256
        self.CHANNELS = 1
        self.CHUNK_SIZE = self.FRAME_SIZE
        
        # FFT setup
        self.window = np.hanning(self.FRAME_SIZE)
        
        # Create a temporary directory for audio processing
        self.temp_dir = tempfile.mkdtemp()
        
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(f"RadioStreamCapture-{station_name}")

    def start(self):
        if self.is_running:
            return
            
        self.is_running = True
        self.thread = threading.Thread(target=self._capture_loop, daemon=True)
        self.thread.start()
        self.logger.info(f"Started capturing stream for {self.station_name}")

    def stop(self):
        self.is_running = False
        if self.thread:
            self.thread.join()
        self.audio.terminate()
        # Clean up temporary files
        try:
            import shutil
            shutil.rmtree(self.temp_dir)
        except Exception as e:
            self.logger.error(f"Error cleaning up temp directory: {str(e)}")
        self.logger.info(f"Stopped capturing stream for {self.station_name}")

    def _convert_aac_to_wav(self, aac_data):
        """Convert AAC data to WAV format using ffmpeg"""
        try:
            # Create temporary files
            aac_file = os.path.join(self.temp_dir, f"temp_{int(time.time())}.aac")
            wav_file = os.path.join(self.temp_dir, f"temp_{int(time.time())}.wav")
            
            # Write AAC data to file
            with open(aac_file, 'wb') as f:
                f.write(aac_data)
            
            # Convert to WAV using ffmpeg
            stream = ffmpeg.input(aac_file)
            stream = ffmpeg.output(stream, wav_file, acodec='pcm_s16le', ac=1, ar=self.SAMPLE_RATE)
            ffmpeg.run(stream, capture_stdout=True, capture_stderr=True, overwrite_output=True)
            
            # Read WAV data
            with open(wav_file, 'rb') as f:
                wav_data = f.read()
            
            # Clean up temporary files
            os.remove(aac_file)
            os.remove(wav_file)
            
            return wav_data
            
        except Exception as e:
            self.logger.error(f"Error converting AAC to WAV: {str(e)}")
            return None

    def _capture_loop(self):
        while self.is_running:
            try:
                # Stream the audio using requests with headers
                response = requests.get(self.stream_url, stream=True, headers=self.headers)
                if response.status_code != 200:
                    self.logger.error(f"Failed to connect to stream: {response.status_code}")
                    time.sleep(5)
                    continue

                buffer = BytesIO()
                for chunk in response.iter_content(chunk_size=self.CHUNK_SIZE):
                    if not self.is_running:
                        break
                        
                    if chunk:
                        buffer.write(chunk)
                        
                        if buffer.tell() >= self.CHUNK_SIZE * 2:  # Buffer more data for AAC conversion
                            # Process the audio chunk
                            buffer.seek(0)
                            aac_data = buffer.read()
                            
                            # Convert AAC to WAV
                            wav_data = self._convert_aac_to_wav(aac_data)
                            if wav_data:
                                # Convert to float32 array
                                audio_data = np.frombuffer(wav_data[44:], dtype=np.int16).astype(np.float32) / 32768.0
                                frames = self._process_audio_chunk(audio_data)
                                
                                if frames:
                                    timestamp = int(time.time() * 1000)
                                    self._add_fingerprint(frames, timestamp)
                            
                            buffer = BytesIO()

                # If we get here, the stream ended
                self.logger.warning(f"Stream ended for {self.station_name}, attempting to reconnect...")
                time.sleep(5)

            except Exception as e:
                self.logger.error(f"Error in capture loop: {str(e)}")
                time.sleep(5)  # Wait before retrying

    def _process_audio_chunk(self, audio_data):
        # Split audio into overlapping frames and extract 4D features per frame
        frames = []
        step = self.FRAME_SIZE - self.FRAME_OVERLAP
        for start in range(0, len(audio_data) - self.FRAME_SIZE + 1, step):
            frame = audio_data[start:start+self.FRAME_SIZE]
            if len(frame) < self.FRAME_SIZE:
                continue
            # Windowing
            float_frame = frame * self.window
            # RMS
            rms = np.sqrt(np.mean(float_frame ** 2)).astype(np.float32)
            # Energy
            energy = np.mean(float_frame ** 2).astype(np.float32)
            # FFT for centroid
            fft = np.fft.rfft(float_frame)
            magnitudes = np.abs(fft)
            freqs = np.fft.rfftfreq(self.FRAME_SIZE, 1.0 / self.SAMPLE_RATE)
            mag_sum = np.sum(magnitudes) if np.sum(magnitudes) > 0 else 1.0
            centroid = (np.sum(freqs * magnitudes) / mag_sum).astype(np.float32)
            norm_centroid = centroid / (self.SAMPLE_RATE / 2.0)
            # dB
            db = 20 * np.log10(rms + 1e-10)
            # Match app normalization
            norm_rms = rms
            norm_energy = energy / self.FRAME_SIZE
            norm_db = db.astype(np.float32)
            frames.append([float(norm_rms), float(norm_centroid), float(norm_energy), float(norm_db)])
        return frames

    def _add_fingerprint(self, frames, timestamp):
        self.fingerprints.append((timestamp, frames))
        # Remove old fingerprints
        cutoff = int(time.time() * 1000) - self.buffer_seconds * 1000
        while self.fingerprints and self.fingerprints[0][0] < cutoff:
            self.fingerprints.popleft()
        # Save to JSON (match app format)
        project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        out_path = os.path.join(project_root, 'LOGGING', 'fingerprints')
        os.makedirs(out_path, exist_ok=True)
        filename = f"{time.strftime('%H-%M-%S')}_LiveStreamFingerprint_{self.station_name}_7s.json"
        with open(os.path.join(out_path, filename), 'w', encoding='utf-8') as f:
            json.dump({
                "fingerprint": frames,
                "timestamp": timestamp,
                "station": self.station_name
            }, f)
        self.logger.info(f"Saved reference fingerprint locally at {os.path.join(out_path, filename)}")

    def get_fingerprints(self):
        """Return a copy of the current fingerprints buffer"""
        return list(self.fingerprints)

    def get_station_name(self):
        return self.station_name 