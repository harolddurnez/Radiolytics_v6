import os
import time
import json
import numpy as np
import firebase_admin
from firebase_admin import credentials, storage, firestore
import logging
from datetime import datetime
import threading
from collections import deque
from dotenv import load_dotenv
import csv
from typing import List, Tuple, Optional, Dict, Any
import argparse
import pandas as pd
import subprocess
import sys

"""
Radiolytics Fingerprint Matcher

Responsibilities:
- For each app fingerprint (from CLI or polling):
    - Load all reference fingerprints
    - Run robust matching logic (sliding window, similarity, threshold)
    - Log all comparisons and outcomes
    - Write result to Firestore with: matched_at, station, similarity, offset, app_fp_filename, match_status, etc.
- All matching, thresholding, and logging is unified here.

Usage:
    python fingerprint_matcher.py --match-app-fingerprint <path_to_app_fp.json>
    python fingerprint_matcher.py --run-matcher
    python fingerprint_matcher.py --analyze-log

Fingerprint JSON format:
{
    "fingerprint": [[RMS, centroid, energy, dB], ...],
    "timestamp": <int>,
    "device_id" or "station": <str>
}

Expected flow:
- Load reference and app fingerprints (N x 4 float arrays)
- For each app fingerprint, slide over reference fingerprints using a window/cross-correlation
- Find the best alignment (offset) and similarity
- Log successful matches to CSV
- Configurable thresholds via config.json or CLI
"""

# --- CONFIGURATION ---
CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')
with open(CONFIG_PATH, 'r') as f:
    config = json.load(f)
POLL_INTERVAL = config.get('POLL_INTERVAL', 5)
MATCH_THRESHOLD = config.get('MATCH_THRESHOLD', 0.75)
MIN_FRAMES_MATCH = config.get('MIN_FRAMES_MATCH', 10)
BUFFER_MINUTES = config.get('BUFFER_MINUTES', 3)
LOG_CSV = config.get('LOG_CSV', 'successful_matches.csv')

# --- LOGGING SETUP ---
LOGGING_DIR = os.path.join(os.path.dirname(__file__), '../LOGGING')
os.makedirs(LOGGING_DIR, exist_ok=True)

# Fingerprint folders inside LOGGING
REFERENCE_FP_DIR = os.path.join(LOGGING_DIR, 'fingerprints')
APP_FP_DIR = None  # No longer used
os.makedirs(REFERENCE_FP_DIR, exist_ok=True)

# Clear only LOGGING/fingerprints at the start of each run
for fp_dir in [REFERENCE_FP_DIR]:
    for f in os.listdir(fp_dir):
        fp = os.path.join(fp_dir, f)
        if os.path.isfile(fp):
            os.remove(fp)

# Update all log file paths to use LOGGING_DIR
LOG_FILE_PATH = os.path.join(LOGGING_DIR, 'radiolytics_server.log')
REFERENCE_RECORDER_LOG_PATH = os.path.join(LOGGING_DIR, 'reference_recorder.log')
MATCH_LOG_PATH = os.path.join(LOGGING_DIR, 'match.log')

# Clear logs at the start of each run
for log_path in [LOG_FILE_PATH, REFERENCE_RECORDER_LOG_PATH, MATCH_LOG_PATH]:
    with open(log_path, 'w') as f:
        f.write('=== Log Cleared for New Run ===\n')

# Custom formatter to add separators between report instances
class ReportSeparatorFormatter(logging.Formatter):
    def __init__(self, fmt=None, datefmt=None):
        super().__init__(fmt, datefmt)
        self.last_report_time = None
        self.separator = "\n" + "="*80 + "\n"  # 80-character separator line

    def format(self, record):
        # Add separator between different report instances (fingerprint processing)
        if hasattr(record, 'fingerprint_id'):
            current_time = time.time()
            if self.last_report_time is None or (current_time - self.last_report_time) > 1.0:
                # New report instance
                self.last_report_time = current_time
                return self.separator + super().format(record)
        return super().format(record)

# Set up logging with the custom formatter
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s | %(levelname)-8s | %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE_PATH, encoding='utf-8'),
        logging.StreamHandler()
    ]
)

# Apply custom formatter to all handlers
formatter = ReportSeparatorFormatter('%(asctime)s | %(levelname)-8s | %(message)s')
for handler in logging.getLogger().handlers:
    handler.setFormatter(formatter)

logger = logging.getLogger(__name__)

# Add custom log formatters for different types of messages
def format_match_log(app_fp: str, ref_ts: int, station: str, similarity: float, offset: int, is_match: bool = False) -> str:
    """Format a match comparison log message."""
    match_indicator = "MATCH" if is_match else "COMPARE"
    return f"{match_indicator} | {app_fp} -> {station} (ts={ref_ts}) | sim={similarity:.3f} | offset={offset}"

def format_summary_log(app_fp: str, app_ts: int, best_match: Optional[Tuple], best_sim: float, best_station: str, best_offset: int) -> str:
    """Format a summary log message."""
    if best_match:
        return f"SUMMARY | {app_fp} (ts={app_ts}) -> {best_match[1]} (ts={best_match[0]}) | sim={best_match[2]:.3f} | offset={best_match[3]}"
    else:
        return f"NO MATCH | {app_fp} (ts={app_ts}) -> No match | Best: {best_station} (sim={best_sim:.3f}, offset={best_offset})"

def format_error_log(error_type: str, details: str) -> str:
    """Format an error log message."""
    return f"ERROR | {error_type} | {details}"

def format_info_log(info_type: str, details: str) -> str:
    """Format an info log message."""
    return f"INFO | {info_type} | {details}"

def log_report_start(app_fp: str, app_ts: int):
    """Log the start of a new fingerprint report."""
    logger.info(format_info_log("REPORT", f"Starting new fingerprint report for {app_fp} (ts={app_ts})"), extra={'fingerprint_id': f"{app_fp}_{app_ts}"})

# --- FIREBASE SETUP ---
load_dotenv()

cred_path = os.getenv("GOOGLE_APPLICATION_CREDENTIALS")
cred = credentials.Certificate(cred_path)
firebase_admin.initialize_app(cred, {
    'storageBucket': 'newbuckettest.firebasestorage.app'
})
bucket = storage.bucket()
db = firestore.client()

# Update all local fingerprint file output to use LOGGING/fingerprints and LOGGING/app_fingerprints
FINGERPRINT_OUTPUT_PATH = REFERENCE_FP_DIR
APP_FINGERPRINT_OUTPUT_PATH = REFERENCE_FP_DIR

# Add match.log handler and logger
match_log_handler = logging.FileHandler(MATCH_LOG_PATH, encoding='utf-8')
match_log_handler.setFormatter(formatter)
match_logger = logging.getLogger('match_logger')
match_logger.setLevel(logging.INFO)
if not any(isinstance(h, logging.FileHandler) and h.baseFilename == match_log_handler.baseFilename for h in match_logger.handlers):
    match_logger.addHandler(match_log_handler)

class FingerprintMatcher:
    def __init__(self):
        """Initialize matcher, load config, and set up logging."""
        self.processed_files = set()
        self.reference_fingerprints: Dict[str, List[Tuple[int, str, List[List[float]]]]] = {}
        self.MATCH_THRESHOLD = MATCH_THRESHOLD
        self.MIN_FRAMES_MATCH = MIN_FRAMES_MATCH
        self.BUFFER_MINUTES = BUFFER_MINUTES
        self.is_running = False
        self.thread = None
        self.log_csv = LOG_CSV
        
        # Initialize reference fingerprint buffers for each station
        self._load_station_config()
        
        # Use module-level Firebase instances
        self.bucket = bucket
        self.db = db
        
        # Create processed_fingerprints directory if it doesn't exist
        os.makedirs('processed_fingerprints', exist_ok=True)
        
        self.last_app_fingerprint_time = 0  # Track last downloaded AppFingerprint
        
        logger.info("Initialized FingerprintMatcher with threshold %.2f and min frames %d", 
                   self.MATCH_THRESHOLD, self.MIN_FRAMES_MATCH)

    def _load_station_config(self):
        """Load station names from config.json"""
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
            for station in config.get('stations', {}).keys():
                self.reference_fingerprints[station] = []
        except Exception as e:
            logger.error(f"Error loading config: {str(e)}")

    def start(self):
        if self.is_running:
            return
            
        self.is_running = True
        self.thread = threading.Thread(target=self._match_loop, daemon=True)
        self.thread.start()
        logger.info("Started fingerprint matcher")

    def stop(self):
        self.is_running = False
        if self.thread:
            self.thread.join()
        logger.info("Stopped fingerprint matcher")

    def _match_loop(self):
        """Main loop that polls for new fingerprints and processes them"""
        while self.is_running:
            try:
                # Load new reference fingerprints
                self._load_reference_fingerprints()
                # self._process_incoming_fingerprints()  # Removed: matching is now triggered via CLI
                time.sleep(POLL_INTERVAL)
            except Exception as e:
                logger.error(f"Error in match loop: {str(e)}")
                time.sleep(5)  # Wait before retrying

    def _load_reference_fingerprints(self):
        """Load new reference fingerprints from Firebase Storage"""
        try:
            cutoff_time = int(time.time()) - (self.BUFFER_MINUTES * 60)
            
            # List all fingerprints (reference and app) from the root 'fingerprints/' folder
            blobs = self.bucket.list_blobs(prefix="fingerprints/")
            for blob in blobs:
                if not blob.name.endswith('.json'):
                    continue
                    
                # Extract timestamp and station from filename
                try:
                    filename = blob.name.split('/')[-1]
                    # Handle both LiveStreamFingerprint and AppFingerprint formats
                    # Format: <HH-mm-ss>_<prefix>_<station>_<interval>s.json or <HH-mm-ss>_<prefix>_<interval>s.json
                    parts = filename.split('_')
                    if len(parts) < 3:  # Need at least HH-mm-ss, prefix, and station/interval
                        continue
                        
                    # Extract timestamp from HH-mm-ss format
                    time_str = parts[0]
                    hh, mm, ss = map(int, time_str.split('-'))
                    now = datetime.now()
                    dt = now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
                    timestamp = int(dt.timestamp())
                    
                    # Extract station name
                    if 'LiveStreamFingerprint' in filename:
                        # For LiveStreamFingerprint: HH-mm-ss_LiveStreamFingerprint_station_interval.json
                        station = parts[2]
                    else:
                        # For AppFingerprint: HH-mm-ss_AppFingerprint_interval.json
                        continue  # Skip app fingerprints in reference loading
                        
                except (ValueError, IndexError):
                    continue
                    
                # Skip if too old
                if timestamp < cutoff_time:
                    continue
                    
                # Skip if already in buffer
                if any(ref_ts == timestamp and ref_st == station for ref_ts, ref_st, _ in self.reference_fingerprints.get(station, [])):
                    continue
                
                # Download and parse
                try:
                    data = json.loads(blob.download_as_text())
                    fingerprint = data.get('fingerprint')
                    if fingerprint:
                        if station not in self.reference_fingerprints:
                            self.reference_fingerprints[station] = []
                        self.reference_fingerprints[station].append((timestamp, station, fingerprint))
                        logger.info(f"Loaded reference fingerprint for {station} at {timestamp}")
                except Exception as e:
                    logger.error(f"Error loading reference fingerprint {blob.name}: {str(e)}")
            
            # Remove old fingerprints from each station's buffer
            for station in self.reference_fingerprints:
                self.reference_fingerprints[station] = [
                    (ref_ts, ref_st, ref_fp) for ref_ts, ref_st, ref_fp in self.reference_fingerprints[station]
                    if ref_ts >= cutoff_time
                ]
            
            # Download any new AppFingerprints from Firebase
            self._download_app_fingerprints()
            
        except Exception as e:
            logger.error(f"Error loading reference fingerprints: {str(e)}")

    def _download_app_fingerprints(self):
        """Download new AppFingerprints from Firebase and save them locally, with detailed logging."""
        try:
            logger.info(format_info_log("SCAN", "Scanning Firebase for new AppFingerprints..."))
            blobs = self.bucket.list_blobs(prefix="fingerprints/")
            found_any = False
            device_files = {}
            
            for blob in blobs:
                if "AppFingerprint" in blob.name and blob.name.endswith(".json"):
                    found_any = True
                    try:
                        time_str = blob.name.split('/')[-1].split('_')[0]
                        hh, mm, ss = map(int, time_str.split('-'))
                        now = datetime.now()
                        dt = now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
                        timestamp = int(dt.timestamp())
                        
                        if timestamp > self.last_app_fingerprint_time:
                            logger.info(format_info_log("PROCESS", f"Processing {blob.name} (ts={timestamp})"))
                            
                            try:
                                data = json.loads(blob.download_as_text())
                            except Exception as e:
                                logger.error(format_error_log("DOWNLOAD", f"Could not download or parse {blob.name}: {e}"))
                                continue
                            device_id = data.get('device_id', 'unknown')
                            
                            if device_id not in device_files:
                                device_files[device_id] = []
                            device_files[device_id].append((timestamp, blob, data))
                            
                            try:
                                blob.make_public()
                                logger.info(format_info_log("PUBLIC", f"Made {blob.name} public: {blob.public_url}"))
                            except Exception as e:
                                logger.error(format_error_log("PUBLIC", f"Could not make {blob.name} public: {e}"))
                            
                            local_path = os.path.join(FINGERPRINT_OUTPUT_PATH, os.path.basename(blob.name))
                            os.makedirs(os.path.dirname(local_path), exist_ok=True)
                            with open(local_path, 'w', encoding='utf-8') as f:
                                json.dump(data, f)
                            logger.info(format_info_log("SAVE", f"Saved to {local_path}"))
                            
                            self.last_app_fingerprint_time = max(self.last_app_fingerprint_time, timestamp)
                            
                    except Exception as e:
                        logger.error(format_error_log("PROCESS_ERROR", f"Error processing {blob.name}: {str(e)}"))
                        continue
            
            if not found_any:
                logger.warning(format_info_log("SCAN", "No new AppFingerprints found"))
                return
            
            # Process each device's newest file
            for device_id, files in device_files.items():
                files_sorted = sorted(files, key=lambda x: x[0], reverse=True)
                newest = files_sorted[0]
                timestamp, blob, data = newest
                
                if blob.name in self.processed_files:
                    continue
                    
                uploaded_fp = data.get('fingerprint')
                uploaded_ts = data.get('timestamp')
                
                debug_log_lines = []
                def debug_logger(msg):
                    debug_log_lines.append(msg)
                    logger.info(msg)
                    match_logger.info(msg)
                best_match, summary_line = self._find_best_match_with_log(
                    uploaded_fp, 
                    app_fp_filename=os.path.basename(blob.name),
                    app_fp_timestamp=uploaded_ts,
                    debug_logger=debug_logger
                )
                
                # Log match result to match.log
                if best_match:
                    match_ts, match_station, similarity, offset = best_match
                    try:
                        self._log_successful_match(
                            os.path.basename(blob.name),
                            match_station,
                            similarity,
                            offset,
                            len(uploaded_fp),
                            offset,
                            datetime.now().isoformat()
                        )
                    except Exception as e:
                        logger.error(format_error_log("LOG_ERROR", f"Error logging match: {e}"))
                    doc_id = str(uploaded_ts)
                    result = {
                        "matched_at": int(time.time() * 1000),
                        "match_timestamp": match_ts,
                        "station": match_station,
                        "confidence": float(similarity),
                        "debug_log": summary_line,
                        "time_str": doc_id
                    }
                    self.db.collection("results").document(doc_id).set(result)
                    logger.info(format_info_log("FIRESTORE", f"Wrote match result: {match_station} (sim={similarity:.3f}) at {doc_id}"))
                    match_logger.info(f"MATCH | {os.path.basename(blob.name)} -> {match_station} | sim={similarity:.3f} | offset={offset}")
                else:
                    doc_id = str(uploaded_ts)
                    result = {
                        "matched_at": int(time.time() * 1000),
                        "station": "Unknown",
                        "confidence": 0.0,
                        "debug_log": summary_line,
                        "time_str": doc_id
                    }
                    self.db.collection("results").document(doc_id).set(result)
                    logger.info(format_info_log("FIRESTORE", "Wrote NO MATCH result"))
                    match_logger.info(f"NO MATCH | {os.path.basename(blob.name)}")
                self.processed_files.add(blob.name)
                
        except Exception as e:
            logger.error(format_error_log("DOWNLOAD_ERROR", f"Error processing fingerprints: {e}"))
            logger.error("Full error details:", exc_info=True)

    def _find_best_match_with_log(self, uploaded_fp: List[List[float]], app_fp_filename: str = "", app_fp_timestamp: int = 0, debug_logger=None) -> (Optional[Tuple[int, str, float, int]], str):
        """
        Find the best matching reference fingerprint using sliding window/cross-correlation.
        Returns (timestamp, station, similarity, offset) for the best match.
        Logs every comparison, best match, and warnings as requested.
        """
        try:
            # Log start of new report
            log_report_start(app_fp_filename, app_fp_timestamp)
            if debug_logger:
                debug_logger(f"App fingerprint: {app_fp_filename}, timestamp: {app_fp_timestamp}")

            # --- Feature scaling function ---
            def scale_features(fp):
                # [RMS, centroid, energy, dB]
                # App: RMS~0.01-0.1, centroid~0.1-0.4, energy~0.01, dB~-40 to -15
                # Ref: RMS~0.5, centroid~0.5, energy~0.4, dB~-5
                # Scale first 3 features by 0.02, leave dB as is
                return [[f[0]*0.02, f[1]*0.02, f[2]*0.02, f[3]] for f in fp]

            # --- Filter out silence frames from reference fingerprints ---
            filtered_reference_fps = {}
            for ref_key, ref_fp_list in self.reference_fingerprints.items():
                # ref_fp_list is a list of (timestamp, station, fingerprint)
                for ref_ts, ref_st, ref_fp in ref_fp_list:
                    filtered = [f for f in ref_fp if f[3] > -150]
                    key = f"{ref_st}_{ref_ts}"
                    filtered_reference_fps[key] = scale_features(filtered)
                    if debug_logger:
                        debug_logger(f"Reference {key}: {len(filtered)} valid frames after silence filter")

            # --- Scale app fingerprint ---
            scaled_app_fp = scale_features(uploaded_fp)
            if debug_logger:
                debug_logger(f"App fingerprint: {len(scaled_app_fp)} frames after scaling")

            # --- Matching logic ---
            best_sim = float('-inf')
            best_match = None
            best_station = None
            best_offset = 0
            for ref_key, ref_fp in filtered_reference_fps.items():
                ref_len = len(ref_fp)
                app_len = len(scaled_app_fp)
                if ref_len < app_len:
                    continue  # Not enough data to match
                for offset in range(ref_len - app_len + 1):
                    ref_window = ref_fp[offset:offset+app_len]
                    # Compute mean cosine similarity over all frames
                    sim_sum = 0.0
                    for i in range(app_len):
                        a = scaled_app_fp[i]
                        b = ref_window[i]
                        # Only compare if both are not silence
                        if a[3] > -150 and b[3] > -150:
                            dot = sum([a[j]*b[j] for j in range(3)])
                            norm_a = sum([a[j]**2 for j in range(3)]) ** 0.5
                            norm_b = sum([b[j]**2 for j in range(3)]) ** 0.5
                            if norm_a > 0 and norm_b > 0:
                                sim_sum += dot / (norm_a * norm_b)
                    similarity = sim_sum / app_len
                    if debug_logger:
                        debug_logger(f"Sim {ref_key} offset {offset}: {similarity}")
                    if similarity > best_sim:
                        best_sim = similarity
                        best_match = (ref_key, similarity, offset)
            if best_match:
                ref_key, similarity, offset = best_match
                # Extract station and timestamp from ref_key
                if '_' in ref_key:
                    station, ts = ref_key.rsplit('_', 1)
                else:
                    station, ts = ref_key, ''
                return (None if similarity < self.MATCH_THRESHOLD else (app_fp_timestamp, station, similarity, offset), f"Best match: {station} sim={similarity} offset={offset}")
            else:
                return (None, "No valid match found.")
        except Exception as e:
            if debug_logger:
                debug_logger(f"Exception in matcher: {e}")
            return (None, f"Exception: {e}")

    def _log_successful_match(self, query_filename, reference_filename, similarity, offset, recording_length, time_offset, dt):
        """Log a successful match to the CSV log."""
        try:
            with open(self.log_csv, 'a') as f:
                f.write(f"{query_filename},{reference_filename},{similarity},{offset},{recording_length},{time_offset},{dt}\n")
        except Exception as e:
            logger.error(f"Error writing to log CSV: {e}")

def analyze_log(log_csv: str):
    """
    Analyze the match log and print trends, best recording lengths, offsets, and station reliability.
    Print actionable suggestions based on log data.
    """
    try:
        df = pd.read_csv(log_csv, header=None, names=[
            'query_filename', 'reference_filename', 'similarity', 'offset', 'recording_length', 'time_offset', 'datetime'])
        if df.empty:
            print("No matches logged yet.")
            return
        print("\n=== Match Log Analytics ===")
        print(f"Total matches: {len(df)}")
        # Best average similarity by recording length
        best_len = df.groupby('recording_length')['similarity'].mean().idxmax()
        print(f"Best recording length (avg similarity): {best_len} frames")
        # Best average similarity by offset
        best_offset = df.groupby('offset')['similarity'].mean().idxmax()
        print(f"Best offset (avg similarity): {best_offset} frames")
        # Most reliably matched station
        best_station = df.groupby('reference_filename')['similarity'].mean().idxmax()
        print(f"Most reliably matched station: {best_station}")
        # Suggestion
        print(f"\nSuggestion: Try recording {best_len / 8:.1f} seconds for best results (assuming 8 frames/sec)")
        print("==========================\n")
    except Exception as e:
        print(f"Error analyzing log: {e}")

def load_json_file(path: str) -> Any:
    """Utility to load a JSON file with error handling."""
    try:
        with open(path, 'r') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading JSON file {path}: {str(e)}")
        return None

def save_json_file(path: str, data: Any) -> bool:
    """Utility to save a JSON file with error handling."""
    try:
        with open(path, 'w') as f:
            json.dump(data, f)
        return True
    except Exception as e:
        logger.error(f"Error saving JSON file {path}: {str(e)}")
        return False

def extract_timestamp_from_filename(filename):
    # Handle both LiveStreamFingerprint and AppFingerprint formats
    # Format: <HH-mm-ss>_<prefix>_<station>_<interval>s.json or <HH-mm-ss>_<prefix>_<interval>s.json
    try:
        time_str = filename.split('_')[0]  # Get HH-mm-ss part
        hh, mm, ss = map(int, time_str.split('-'))
        # Create a datetime for today with the extracted minutes and seconds
        now = datetime.now()
        dt = now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
        return int(dt.timestamp())
    except (ValueError, IndexError):
        return None

def open_log_in_vscode():
    """Open the log file in VS Code with auto-update enabled."""
    try:
        # Get the absolute path to the log file
        log_path = os.path.abspath(LOG_FILE_PATH)
        
        # Try to open in VS Code
        if sys.platform == 'win32':
            # Windows
            subprocess.Popen(['code', '--new-window', log_path], 
                           creationflags=subprocess.CREATE_NEW_CONSOLE)
        else:
            # Linux/Mac
            subprocess.Popen(['code', '--new-window', log_path])
            
        print(f"Opening log file in VS Code: {log_path}")
        print("Tip: The log will auto-update as new entries are added")
    except Exception as e:
        print(f"Could not open log in VS Code: {e}")
        print(f"Please open {LOG_FILE_PATH} manually in your preferred text editor")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Radiolytics Fingerprint Matcher CLI")
    parser.add_argument('--analyze-log', action='store_true', help='Analyze the match log and print trends')
    parser.add_argument('--log-csv', type=str, default=LOG_CSV, help='Path to match log CSV')
    parser.add_argument('--run-matcher', action='store_true', help='Run the fingerprint matcher service')
    parser.add_argument('--match-app-fingerprint', type=str, help='Path to a single app fingerprint JSON file to match and write result to Firestore')
    args = parser.parse_args()

    if args.analyze_log:
        try:
            analyze_log(args.log_csv)
        except Exception as e:
            print(f"Error running log analysis: {e}")
    elif args.run_matcher:
        matcher = None
        try:
            # open_log_in_vscode()  # Commented out to avoid VS Code errors
            matcher = FingerprintMatcher()
            matcher.start()
            print("Matcher service started. Press Ctrl+C to stop.")
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("Shutting down...")
            print("Matcher service stopped.")
        except Exception as e:
            logger.error(f"Error running matcher: {str(e)}")
            print(f"Error running matcher: {e}")
        finally:
            if matcher:
                matcher.stop()
    elif args.match_app_fingerprint:
        # Process a single app fingerprint file
        matcher = FingerprintMatcher()
        # Load reference fingerprints
        matcher._load_reference_fingerprints()
        # Load the app fingerprint
        with open(args.match_app_fingerprint, 'r') as f:
            data = json.load(f)
        uploaded_fp = data.get('fingerprint')
        uploaded_ts = data.get('timestamp')
        app_fp_filename = os.path.basename(args.match_app_fingerprint)
        debug_log_lines = []
        def debug_logger(msg):
            debug_log_lines.append(msg)
            logger.info(msg)
        best_match, summary_line = matcher._find_best_match_with_log(
            uploaded_fp,
            app_fp_filename=app_fp_filename,
            app_fp_timestamp=uploaded_ts,
            debug_logger=debug_logger
        )
        if best_match:
            match_ts, match_station, similarity, offset = best_match
            match_status = "MATCH" if similarity >= matcher.MATCH_THRESHOLD else "NO MATCH"
            result = {
                "matched_at": int(time.time() * 1000),
                "match_timestamp": match_ts,
                "station": match_station,
                "similarity": float(similarity),
                "offset": offset,
                "app_fp_filename": app_fp_filename,
                "match_status": match_status,
                "debug_log": summary_line
            }
        else:
            result = {
                "matched_at": int(time.time() * 1000),
                "station": "NO MATCH",
                "similarity": 0.0,
                "offset": -1,
                "app_fp_filename": app_fp_filename,
                "match_status": "NO MATCH",
                "debug_log": summary_line
            }
        # Write result to Firestore using timestamp or filename as doc ID
        doc_id = str(uploaded_ts) if uploaded_ts else app_fp_filename
        matcher.db.collection("results").document(doc_id).set(result)
        logger.info(format_info_log("FIRESTORE", f"Wrote match result: {result['station']} (sim={result['similarity']:.3f}) for {app_fp_filename}"))
    else:
        print("No valid command provided. Use --help for usage information.")
        parser.print_help() 