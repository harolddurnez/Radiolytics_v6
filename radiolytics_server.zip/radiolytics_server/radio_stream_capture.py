import pyaudio
import numpy as np
import threading
import time
import requests
from io import BytesIO
import logging
from pydub import AudioSegment
import ffmpeg
import tempfile
import os
from collections import deque

class RadioStreamCapture:
    def __init__(self, stream_url, station_name, headers=None, buffer_seconds=60):
        self.stream_url = stream_url
        self.station_name = station_name
        self.headers = headers or {}
        self.buffer_seconds = buffer_seconds
        self.is_running = False
        self.thread = None
        self.fingerprints = deque()  # (timestamp, fingerprint)
        self.audio = pyaudio.PyAudio()
        
        # Audio parameters (matching Android app)
        self.SAMPLE_RATE = 44100
        self.CHANNELS = 1
        self.FRAME_SIZE = 2048    # Match Android's FRAME_SIZE
        self.FRAME_OVERLAP = 1024 # Match Android's FRAME_OVERLAP
        self.CHUNK_SIZE = self.FRAME_SIZE * 2  # Process larger chunks for overlap
        
        # Audio quality parameters
        self.SILENCE_THRESHOLD = -50.0  # dB threshold for silence
        self.MIN_AUDIO_LEVEL = -30.0    # Minimum acceptable audio level
        self.MAX_AUDIO_LEVEL = -3.0     # Maximum acceptable audio level
        self.NORMALIZE_TARGET = -20.0   # Target level for normalization
        
        # Buffer for frame overlap
        self.prev_frame = np.zeros(self.FRAME_OVERLAP, dtype=np.float32)
        self.audio_buffer = BytesIO()  # Buffer for continuous audio stream
        
        # FFT setup
        self.fft = np.fft.fft
        self.window = np.hanning(self.FRAME_SIZE)
        
        # Create a temporary directory for audio processing
        self.temp_dir = tempfile.mkdtemp()
        
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(f"RadioStreamCapture-{station_name}")

    def start(self):
        if self.is_running:
            return
            
        self.is_running = True
        self.thread = threading.Thread(target=self._capture_loop, daemon=True)
        self.thread.start()
        self.logger.info(f"Started capturing stream for {self.station_name}")

    def stop(self):
        self.is_running = False
        if self.thread:
            self.thread.join()
        self.audio.terminate()
        # Clean up temporary files
        try:
            import shutil
            shutil.rmtree(self.temp_dir)
        except Exception as e:
            self.logger.error(f"Error cleaning up temp directory: {str(e)}")
        self.logger.info(f"Stopped capturing stream for {self.station_name}")

    def _convert_aac_to_wav(self, aac_data):
        """Convert AAC data to WAV format using ffmpeg"""
        try:
            # Create temporary files
            aac_file = os.path.join(self.temp_dir, f"temp_{int(time.time())}.aac")
            wav_file = os.path.join(self.temp_dir, f"temp_{int(time.time())}.wav")
            
            # Write AAC data to file
            with open(aac_file, 'wb') as f:
                f.write(aac_data)
            
            # Convert to WAV using ffmpeg
            stream = ffmpeg.input(aac_file)
            stream = ffmpeg.output(stream, wav_file, acodec='pcm_s16le', ac=1, ar=self.SAMPLE_RATE)
            ffmpeg.run(stream, capture_stdout=True, capture_stderr=True, overwrite_output=True)
            
            # Read WAV data
            with open(wav_file, 'rb') as f:
                wav_data = f.read()
            
            # Clean up temporary files
            os.remove(aac_file)
            os.remove(wav_file)
            
            return wav_data
            
        except Exception as e:
            self.logger.error(f"Error converting AAC to WAV: {str(e)}")
            return None

    def _is_silence(self, audio_data: np.ndarray) -> bool:
        """Check if the audio chunk is silence"""
        rms = np.sqrt(np.mean(np.square(audio_data)))
        db = 20 * np.log10(rms + 1e-10)
        return db < self.SILENCE_THRESHOLD

    def _normalize_audio(self, audio_data: np.ndarray) -> np.ndarray:
        """Normalize audio to target level"""
        rms = np.sqrt(np.mean(np.square(audio_data)))
        db = 20 * np.log10(rms + 1e-10)
        
        if db < self.MIN_AUDIO_LEVEL or db > self.MAX_AUDIO_LEVEL:
            self.logger.warning(f"Audio level {db:.1f}dB outside acceptable range")
            return None
            
        # Calculate gain to reach target level
        gain = 10 ** ((self.NORMALIZE_TARGET - db) / 20)
        return audio_data * gain

    def _verify_wav_header(self, wav_data: bytes) -> bool:
        """Verify WAV header is valid"""
        if len(wav_data) < 44:
            return False
        # Check RIFF header
        if wav_data[0:4] != b'RIFF' or wav_data[8:12] != b'WAVE':
            return False
        # Check format chunk
        if wav_data[12:16] != b'fmt ':
            return False
        # Verify PCM format
        if wav_data[20:22] != b'\x01\x00':  # 1 = PCM
            return False
        # Verify sample rate
        sample_rate = int.from_bytes(wav_data[24:28], 'little')
        if sample_rate != self.SAMPLE_RATE:
            return False
        return True

    def _capture_loop(self):
        while self.is_running:
            try:
                # Stream the audio using requests with headers
                response = requests.get(self.stream_url, stream=True, headers=self.headers)
                if response.status_code != 200:
                    self.logger.error(f"Failed to connect to stream: {response.status_code}")
                    time.sleep(5)
                    continue

                for chunk in response.iter_content(chunk_size=self.CHUNK_SIZE):
                    if not self.is_running:
                        break
                        
                    if chunk:
                        self.audio_buffer.write(chunk)
                        
                        # Process when we have enough data
                        if self.audio_buffer.tell() >= self.CHUNK_SIZE * 4:  # Increased buffer for better AAC conversion
                            self.audio_buffer.seek(0)
                            aac_data = self.audio_buffer.read()
                            
                            # Convert AAC to WAV
                            wav_data = self._convert_aac_to_wav(aac_data)
                            if wav_data and self._verify_wav_header(wav_data):
                                # Convert to float32 array
                                audio_data = np.frombuffer(wav_data[44:], dtype=np.int16).astype(np.float32) / 32768.0
                                
                                # Skip silence
                                if not self._is_silence(audio_data):
                                    # Normalize audio
                                    audio_data = self._normalize_audio(audio_data)
                                    if audio_data is not None:
                                        frames = self._process_audio_chunk(audio_data)
                                        if frames is not None:
                                            timestamp = int(time.time() * 1000)
                                            self._add_fingerprint(frames, timestamp)
                            
                            # Keep any remaining data
                            self.audio_buffer = BytesIO()
                            if len(aac_data) > self.CHUNK_SIZE * 4:
                                self.audio_buffer.write(aac_data[self.CHUNK_SIZE * 4:])

                # If we get here, the stream ended
                self.logger.warning(f"Stream ended for {self.station_name}, attempting to reconnect...")
                time.sleep(5)

            except Exception as e:
                self.logger.error(f"Error in capture loop: {str(e)}")
                time.sleep(5)  # Wait before retrying

    def _process_audio_chunk(self, audio_data):
        try:
            # Convert to float32 and normalize to [-1, 1]
            audio_float = np.frombuffer(audio_data, dtype=np.float32) / 32768.0
            
            # Process frames with overlap
            frames = []
            current_pos = 0
            
            while current_pos + self.FRAME_SIZE <= len(audio_float):
                # Get current frame
                if current_pos == 0:
                    # First frame: combine with previous frame
                    frame = np.concatenate([self.prev_frame, audio_float[:self.FRAME_SIZE - self.FRAME_OVERLAP]])
                else:
                    frame = audio_float[current_pos:current_pos + self.FRAME_SIZE]
                
                # Apply window function
                windowed = frame * self.window
                
                # Calculate RMS
                rms = np.sqrt(np.mean(np.square(windowed)))
                
                # Calculate spectral centroid
                fft_result = self.fft(windowed)
                magnitudes = np.abs(fft_result[:self.FRAME_SIZE//2])
                freqs = np.fft.fftfreq(self.FRAME_SIZE, 1.0/self.SAMPLE_RATE)[:self.FRAME_SIZE//2]
                
                if np.sum(magnitudes) > 0:
                    centroid = np.sum(freqs * magnitudes) / np.sum(magnitudes)
                    centroid = centroid / (self.SAMPLE_RATE / 2)  # Normalize to [0,1]
                else:
                    centroid = 0.0
                
                # Calculate energy
                energy = np.mean(np.square(windowed))
                
                # Calculate dB
                db = 20 * np.log10(rms + 1e-10)
                
                # Create 4D vector matching Android app format
                frame_vector = [float(rms), float(centroid), float(energy), float(db)]
                frames.append(frame_vector)
                
                # Move to next frame with overlap
                current_pos += (self.FRAME_SIZE - self.FRAME_OVERLAP)
            
            # Save last frame for next overlap
            if len(audio_float) >= self.FRAME_OVERLAP:
                self.prev_frame = audio_float[-self.FRAME_OVERLAP:]
            
            return frames if frames else None
            
        except Exception as e:
            self.logger.error(f"Error processing audio chunk: {str(e)}")
            return None

    def _add_fingerprint(self, frames, timestamp):
        """Add multiple frames to the fingerprint buffer and save to file with feature scaling."""
        if frames is not None:
            # Scale features to match app
            scaled_frames = [[f[0]*0.02, f[1]*0.02, f[2]*0.02, f[3]] for f in frames]
            # Add each frame with its own timestamp
            frame_interval = (self.FRAME_SIZE - self.FRAME_OVERLAP) / self.SAMPLE_RATE * 1000  # ms per frame
            for i, frame in enumerate(scaled_frames):
                frame_timestamp = timestamp + int(i * frame_interval)
                self.fingerprints.append((frame_timestamp, frame))
            # Remove old fingerprints
            cutoff = int(time.time() * 1000) - self.buffer_seconds * 1000
            while self.fingerprints and self.fingerprints[0][0] < cutoff:
                self.fingerprints.popleft()
            # Save to file (if needed)
            # ... existing code for saving ...

    def get_fingerprints(self):
        """Return a copy of the current fingerprints buffer"""
        return list(self.fingerprints)

    def get_station_name(self):
        return self.station_name 