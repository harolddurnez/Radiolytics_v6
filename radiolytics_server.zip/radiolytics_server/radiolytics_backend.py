import os
import time
import threading
import base64
import json
from collections import deque
import firebase_admin
from firebase_admin import credentials, storage, firestore
from radio_stream_capture import RadioStreamCapture
from radio_stations import get_all_stations
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import subprocess
import numpy as np
from typing import List, Tuple, Optional, Dict, Any
from datetime import datetime

# --- CONFIGURATION ---
LIVE_BUFFER_SECONDS = 60  # How many seconds of live fingerprints to keep
MATCH_THRESHOLD = 0.75    # Similarity threshold for matching (0-1 range)
MIN_FRAMES_MATCH = 10     # Minimum number of frames that need to match
FRAME_SIMILARITY_THRESHOLD = 0.6  # Minimum similarity for individual frames
MAX_TIME_DIFF_MS = 5000   # Maximum allowed time difference between app and server frames

# --- LOGGING SETUP ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('radio_capture.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# --- FIREBASE SETUP ---
cred = credentials.Certificate(os.path.join("ADMIN DO NOT COMMIT", "service-account.json"))
firebase_admin.initialize_app(cred, {
    'storageBucket': 'newbuckettest.firebasestorage.app'
})
db = firestore.client()
bucket = storage.bucket()

# --- RADIO STREAM CAPTURE ---
radio_captures = {}  # station_name -> RadioStreamCapture

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

def start_radio_captures():
    """Start capturing audio from all configured radio stations"""
    stations = get_all_stations()
    for station in stations:
        try:
            name = station["name"]
            if name in radio_captures:
                logger.warning(f"Capture already running for {name}")
                continue
                
            logger.info(f"Starting capture for {name}")
            capture = RadioStreamCapture(
                stream_url=station["stream_url"],
                station_name=name,
                headers=station.get("headers", {})
            )
            capture.start()
            radio_captures[name] = capture
            logger.info(f"Successfully started capture for {name}")
            
        except Exception as e:
            logger.error(f"Failed to start capture for {station['name']}: {str(e)}")

def stop_radio_captures():
    """Stop all active radio captures"""
    for name, capture in radio_captures.items():
        try:
            logger.info(f"Stopping capture for {name}")
            capture.stop()
            logger.info(f"Successfully stopped capture for {name}")
        except Exception as e:
            logger.error(f"Error stopping capture for {name}: {str(e)}")
    radio_captures.clear()

def calculate_frame_similarity(fp1: List[float], fp2: List[float]) -> float:
    """Calculate similarity between two 4D vector frames"""
    try:
        # Convert to numpy arrays
        fp1 = np.array(fp1, dtype=np.float32)
        fp2 = np.array(fp2, dtype=np.float32)
        
        # Normalize each feature dimension
        fp1_norm = fp1 / (np.linalg.norm(fp1) + 1e-10)
        fp2_norm = fp2 / (np.linalg.norm(fp2) + 1e-10)
        
        # Calculate cosine similarity
        similarity = np.dot(fp1_norm, fp2_norm)
        return float(similarity)
    except Exception as e:
        logger.error(f"Error calculating frame similarity: {str(e)}")
        return 0.0

def parse_fingerprint_json(uploaded_fp: str) -> List[Dict[str, Any]]:
    """Parse the JSON fingerprint format from the Android app"""
    try:
        data = json.loads(uploaded_fp)
        if not isinstance(data, list):
            raise ValueError("Expected list of frames")
        
        frames = []
        for frame in data:
            if not isinstance(frame, dict):
                continue
                
            features = frame.get("features")
            timestamp = frame.get("timestamp")
            db = frame.get("db")
            
            if not features or not isinstance(features, list) or len(features) != 4:
                continue
            if not timestamp or not isinstance(timestamp, (int, float)):
                continue
                
            frames.append({
                "features": features,
                "timestamp": int(timestamp),
                "db": float(db) if db is not None else None
            })
        
        return frames
    except Exception as e:
        logger.error(f"Error parsing fingerprint JSON: {str(e)}")
        return []

def find_best_frame_match(uploaded_frame: Dict[str, Any], 
                         live_frames: List[Tuple[int, List[float]]], 
                         start_idx: int = 0) -> Tuple[Optional[int], float, int]:
    """Find the best matching frame in the live frames starting from start_idx"""
    best_similarity = -1.0
    best_idx = None
    best_timestamp = None
    
    uploaded_ts = uploaded_frame["timestamp"]
    uploaded_features = uploaded_frame["features"]
    
    for i in range(start_idx, len(live_frames)):
        live_ts, live_features = live_frames[i]
        
        # Check time difference
        time_diff = abs(live_ts - uploaded_ts)
        if time_diff > MAX_TIME_DIFF_MS:
            continue
        
        # Calculate similarity
        similarity = calculate_frame_similarity(uploaded_features, live_features)
        
        # Apply time-based similarity adjustment
        time_factor = 1.0 - (time_diff / MAX_TIME_DIFF_MS) * 0.1  # Up to 10% boost
        adjusted_similarity = similarity * time_factor
        
        if adjusted_similarity > best_similarity:
            best_similarity = adjusted_similarity
            best_idx = i
            best_timestamp = live_ts
    
    return best_timestamp, best_similarity, best_idx if best_idx is not None else start_idx

def match_fingerprint(uploaded_fp):
    """Match a fingerprint against all radio stations using frame-based comparison"""
    try:
        # Parse the uploaded fingerprint
        if isinstance(uploaded_fp, bytes):
            uploaded_fp = uploaded_fp.decode('utf-8')
        
        frames = parse_fingerprint_json(uploaded_fp)
        if not frames:
            logger.error("No valid frames in uploaded fingerprint")
            return None, 0.0, None
        
        # Log fingerprint details
        logger.info(f"Processing fingerprint with {len(frames)} frames")
        if frames:
            first_ts = datetime.fromtimestamp(frames[0]["timestamp"] / 1000)
            last_ts = datetime.fromtimestamp(frames[-1]["timestamp"] / 1000)
            duration = (last_ts - first_ts).total_seconds()
            logger.info(f"Fingerprint duration: {duration:.2f}s, from {first_ts} to {last_ts}")
        
        best_match = None
        best_overall_similarity = -1.0
        best_station = None
        best_timestamp = None
        
        for station_name, capture in radio_captures.items():
            live_frames = capture.get_fingerprints()
            if not live_frames:
                continue
            
            # Try matching at different starting positions
            for start_idx in range(len(live_frames)):
                matched_frames = 0
                total_similarity = 0.0
                current_idx = start_idx
                
                # Try to match each frame in the uploaded fingerprint
                for uploaded_frame in frames:
                    if current_idx >= len(live_frames):
                        break
                    
                    timestamp, similarity, new_idx = find_best_frame_match(
                        uploaded_frame, live_frames, current_idx
                    )
                    
                    if similarity >= FRAME_SIMILARITY_THRESHOLD:
                        matched_frames += 1
                        total_similarity += similarity
                    
                    current_idx = new_idx + 1
                
                # Calculate overall similarity if we have enough matches
                if matched_frames >= MIN_FRAMES_MATCH:
                    overall_similarity = total_similarity / len(frames)
                    if overall_similarity > best_overall_similarity:
                        best_overall_similarity = overall_similarity
                        best_station = station_name
                        best_timestamp = live_frames[start_idx][0]
        
        if best_overall_similarity >= MATCH_THRESHOLD:
            logger.info(f"Found match: {best_station} with similarity {best_overall_similarity:.3f}")
            return best_timestamp, best_overall_similarity, best_station
        
        logger.info(f"No match found. Best similarity: {best_overall_similarity:.3f} with {best_station}")
        return None, best_overall_similarity, None
        
    except Exception as e:
        logger.error(f"Error in fingerprint matching: {str(e)}")
        return None, 0.0, None

# --- POLL FOR NEW MOBILE FINGERPRINTS ---
def poll_firebase_storage():
    processed_files = set()
    while True:
        try:
            blobs = bucket.list_blobs(prefix="incoming_fingerprints/")
            for blob in blobs:
                if blob.name in processed_files:
                    continue
                if not blob.name.endswith(".json"):
                    continue
                # Download and save the fingerprint file locally
                local_path = os.path.join("ADMIN DO NOT COMMIT", os.path.basename(blob.name))
                with open(local_path, 'wb') as f:
                    f.write(blob.download_as_bytes())
                # Call the matcher as a subprocess
                subprocess.run([
                    "python", "radiolytics_server/fingerprint_matcher.py", "--match-app-fingerprint", local_path
                ], check=True)
                processed_files.add(blob.name)
                blob.delete()
        except Exception as e:
            logger.error(f"Error in poll loop: {str(e)}")
        time.sleep(5)

@app.on_event("startup")
async def startup_event():
    """Start radio captures when the server starts"""
    logger.info("Starting radio captures...")
    start_radio_captures()
    
    # Start polling in a separate thread
    poll_thread = threading.Thread(target=poll_firebase_storage, daemon=True)
    poll_thread.start()
    logger.info("Fingerprint polling started")

@app.on_event("shutdown")
async def shutdown_event():
    """Stop radio captures when the server shuts down"""
    logger.info("Stopping radio captures...")
    stop_radio_captures()
    logger.info("All radio captures stopped")

if __name__ == "__main__":
    try:
        logger.info("Starting Radiolytics backend server...")
        uvicorn.run(app, host="0.0.0.0", port=8000)
    except Exception as e:
        logger.error(f"Server error: {str(e)}")
        stop_radio_captures() 